export const T20Players = ['Rohit', 'Gill', 'Kohli'];
export const RanjiTrophyPlayers = ['Sarfaraz', 'Pujara', 'Sundar'];

export const IndianPlayers = [...T20Players, ...RanjiTrophyPlayers];
