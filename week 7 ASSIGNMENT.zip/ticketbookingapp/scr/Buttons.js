
export function LoginButton({ onClick }) {
return <button onClick={onClick}>Login</button>;
}

export function LogoutButton({ onClick }) {
return <button onClick={onClick}>Logout</button>;
}
