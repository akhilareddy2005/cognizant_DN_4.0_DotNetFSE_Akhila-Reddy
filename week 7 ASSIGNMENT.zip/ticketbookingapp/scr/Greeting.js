
export function GuestGreeting() {
return <h2>Please sign up to book tickets.</h2>;
}

export function UserGreeting() {
return <h2>Welcome back! You can book tickets now.</h2>;
}

