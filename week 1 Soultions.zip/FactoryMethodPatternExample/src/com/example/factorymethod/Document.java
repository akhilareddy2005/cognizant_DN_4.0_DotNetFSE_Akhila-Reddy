package com.example.factorymethod;

public interface Document {
	void open();

}
